package com.example.esp32camviewer

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {
    private enum class Mode { LIVE, PLAYBACK, BUSY }

    /** kind: 0 = range slider, 1 = on/off switch, 2 = drop-down select */
    private class Spec(val key: String, val label: String, val kind: Int,
                       val min: Int = 0, val max: Int = 1, val options: List<String> = emptyList())

    private val frameNames = arrayOf(
        "96x96", "QQVGA 160x120", "128x128", "QCIF 176x144", "HQVGA 240x176", "240x240", "QVGA 320x240",
        "320x320", "CIF 400x296", "HVGA 480x320", "VGA 640x480", "SVGA 800x600", "XGA 1024x768",
        "HD 1280x720", "SXGA 1280x1024", "UXGA 1600x1200", "FHD 1920x1080", "P_HD 720x1280",
        "P_3MP 864x1536", "QXGA 2048x1536", "QHD 2560x1440", "WQXGA 2560x1600", "P_FHD 1080x1920",
        "QSXGA 2560x1920", "5MP 2592x1944")

    private lateinit var video: ImageView
    private lateinit var ipEdit: EditText
    private lateinit var btn: Button
    private lateinit var info: TextView
    private lateinit var recBtn: Button
    private lateinit var resBtn: Button
    private lateinit var fileBtn: Button
    private lateinit var setBtn: Button
    private lateinit var liveBtn: Button

    private val ui = Handler(Looper.getMainLooper())
    private var client: MjpegClient? = null
    private var poller: StatusPoller? = null
    private var wifi: Network? = null
    private var netCallback: ConnectivityManager.NetworkCallback? = null

    private var connected = false
    private var curNet: Network? = null
    private var curIp = ""
    private var mode = Mode.LIVE
    private var recording = false      // local state: set by the REC button (the device does not report it over HTTP)
    private var busyText: String? = null
    private var errorText: String? = null

    private var status: Map<String, String> = emptyMap()
    private var frames = 0
    private var fps = 0f
    private var frameSize = ""

    private val fpsTick = object : Runnable {
        override fun run() {
            fps = frames.toFloat(); frames = 0
            refreshInfo()
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)
        video = findViewById(R.id.video)
        ipEdit = findViewById(R.id.ipEdit)
        btn = findViewById(R.id.connectBtn)
        info = findViewById(R.id.info)
        recBtn = findViewById(R.id.recBtn)
        resBtn = findViewById(R.id.resBtn)
        fileBtn = findViewById(R.id.fileBtn)
        setBtn = findViewById(R.id.setBtn)
        liveBtn = findViewById(R.id.liveBtn)

        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        ipEdit.setText(prefs.getString("ip", "192.168.4.1"))

        btn.setOnClickListener { if (connected) disconnect() else connect() }
        ipEdit.setOnEditorActionListener { _, id, ev ->
            if (id == EditorInfo.IME_ACTION_GO || (ev?.keyCode == KeyEvent.KEYCODE_ENTER)) {
                if (!connected) connect(); true
            } else false
        }
        recBtn.setOnClickListener { toggleRecord() }
        resBtn.setOnClickListener { openResolution() }
        fileBtn.setOnClickListener { openFiles("/") }
        setBtn.setOnClickListener { openSettings() }
        liveBtn.setOnClickListener { backToLive() }
        updateButtons()
    }

    // ---------------------------------------------------------------- connection

    private fun connect() {
        val ip = ipEdit.text.toString().trim()
        if (ip.isEmpty()) return
        getSharedPreferences("cfg", MODE_PRIVATE).edit().putString("ip", ip).apply()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(ipEdit.windowToken, 0)
        connected = true
        btn.text = "斷線"
        info.text = "連線中..."
        status = emptyMap(); frames = 0; fps = 0f; frameSize = ""; errorText = null
        acquireWifi { net -> ui.post { if (connected) startSession(ip, net) } }
    }

    /** ESP32-CAM AP has no internet: bind to the Wi-Fi network so traffic is not routed to mobile data */
    private fun acquireWifi(done: (Network?) -> Unit) {
        wifi?.let { done(it); return }
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build()
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { wifi = network; cm.bindProcessToNetwork(network); done(network) }
            override fun onUnavailable() { done(null) }
            override fun onLost(network: Network) { if (wifi == network) wifi = null }
        }
        netCallback = cb
        cm.requestNetwork(req, cb, 4000)
    }

    private fun startSession(ip: String, net: Network?) {
        curIp = ip
        curNet = net
        poller = StatusPoller(net, ip) { m -> runOnUiThread { status = m; refreshInfo() } }.also { it.start() }
        ui.removeCallbacks(fpsTick); ui.postDelayed(fpsTick, 1000)
        startLive()
    }

    private fun onFrame(bmp: Bitmap) {
        runOnUiThread {
            video.setImageBitmap(bmp)
            frames++
            errorText = null
            frameSize = "${bmp.width}x${bmp.height}"
        }
    }

    private fun startLive() {
        mode = Mode.LIVE
        busyText = null
        updateButtons()
        client = MjpegClient(curNet, curIp,
            onFrame = { bmp -> onFrame(bmp) },
            onError = { msg -> runOnUiThread { if (connected) errorText = msg } }
        ).also { it.start() }
    }

    private fun stopClient() {
        client?.stop(); client = null
    }

    private fun backToLive() {
        if (!connected) return
        stopClient()
        startLive()
    }

    private fun disconnect() {
        connected = false
        mode = Mode.LIVE
        busyText = null
        btn.text = "連線"
        ui.removeCallbacks(fpsTick)
        stopClient()
        poller?.stop(); poller = null
        info.text = "未連線"
        updateButtons()
    }

    // ---------------------------------------------------------------- helpers

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun px(v: Int) = (v * resources.displayMetrics.density).toInt()

    /** run network work off the UI thread; show a toast and call onFail on error */
    private fun bg(onFail: () -> Unit = {}, work: () -> Unit) {
        Thread {
            try {
                work()
            } catch (e: Exception) {
                runOnUiThread { toast("失敗: ${e.message ?: e.javaClass.simpleName}"); onFail() }
            }
        }.start()
    }

    private fun updateButtons() {
        val live = connected && mode == Mode.LIVE
        recBtn.isEnabled = live
        resBtn.isEnabled = live
        fileBtn.isEnabled = live
        setBtn.isEnabled = live
        liveBtn.visibility = if (mode == Mode.PLAYBACK) View.VISIBLE else View.GONE
        recBtn.text = if (recording) "■ 停止錄影" else "● 錄影"
        recBtn.setTextColor(if (recording) 0xFFFF5252.toInt() else 0xFFFFFFFF.toInt())
    }

    // ---------------------------------------------------------------- record

    /** /control?forceRecord=1|0 */
    private fun toggleRecord() {
        val want = !recording
        bg {
            CamApi.control(curNet, curIp, "forceRecord", if (want) "1" else "0")
            runOnUiThread { recording = want; updateButtons(); refreshInfo() }
        }
    }

    // ---------------------------------------------------------------- resolution

    private fun resolutionsFor(model: String): List<Int> {
        val base = listOf(0, 1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15)   // OV2640
        val list = when (model) {
            "OV3660" -> base + listOf(16, 17, 18, 19)
            "OV5640" -> base + listOf(16, 17, 19, 20, 21, 22, 23)
            "PY260" -> listOf(0, 2, 6, 7, 10, 13, 15, 16, 24)
            else -> base
        }
        return list.sortedDescending()
    }

    private fun openResolution() {
        if (recording) { toast("錄影中無法變更解析度，請先停止錄影"); return }
        bg {
            val cfg = CamApi.status(curNet, curIp)
            runOnUiThread { showResolution(cfg) }
        }
    }

    private fun showResolution(cfg: Map<String, String>) {
        val idxs = resolutionsFor(cfg["camModel"] ?: "OV2640")
        val cur = cfg["framesize"]?.toIntOrNull() ?: -1
        val labels = idxs.map { frameNames[it] }.toTypedArray()
        AlertDialog.Builder(this).setTitle("解析度（${cfg["camModel"] ?: ""}）")
            .setSingleChoiceItems(labels, idxs.indexOf(cur)) { d, which -> d.dismiss(); setResolution(idxs[which]) }
            .setNegativeButton("取消", null).show()
    }

    /** /control?framesize=N, then updateFPS (same as the web page: the device resets FPS to the size's default) */
    private fun setResolution(idx: Int) {
        bg {
            CamApi.control(curNet, curIp, "framesize", idx.toString())
            CamApi.control(curNet, curIp, "updateFPS", idx.toString())
            runOnUiThread { toast("解析度 ${frameNames[idx]}"); poller?.reloadConfig() }
        }
    }

    // ---------------------------------------------------------------- settings

    private fun specsFor(model: String): List<Spec> {
        val ov3 = model == "OV3660" || model == "OV5640"
        val py = model == "PY260"
        return listOf(
            Spec("fps", "FPS（幀率）", 0, 1, 30),
            if (py) Spec("quality", "品質（0 最佳）", 0, 0, 2)
            else Spec("quality", "JPEG 品質（數字越小越好）", 0, 4, 63),
            Spec("brightness", "亮度", 0, if (py) -4 else if (ov3) -3 else -2, if (py) 4 else if (ov3) 3 else 2),
            Spec("contrast", "對比", 0, if (py || ov3) -3 else -2, if (py || ov3) 3 else 2),
            Spec("saturation", "飽和度", 0, if (py) -3 else if (ov3) -4 else -2, if (py) 3 else if (ov3) 4 else 2),
            Spec("special_effect", "特效", 2, options = listOf("無", "負片", "灰階", "偏紅", "偏綠", "偏藍", "復古")),
            Spec("wb_mode", "白平衡", 2, options = listOf("自動", "晴天", "陰天", "辦公室", "室內")),
            Spec("hmirror", "水平鏡像", 1),
            Spec("vflip", "垂直翻轉", 1),
            Spec("enableMotion", "動態偵測", 1),
            Spec("motionVal", "動態偵測靈敏度", 0, 1, 10),
            Spec("minf", "最短錄影秒數", 0, 0, 20)
        )
    }

    private fun openSettings() {
        bg {
            val cfg = CamApi.status(curNet, curIp)
            runOnUiThread { showSettings(cfg) }
        }
    }

    /** every change is sent immediately (/control?key=value); "儲存到裝置" makes them permanent (save=1) */
    private fun applySetting(key: String, value: String) {
        bg { CamApi.control(curNet, curIp, key, value) }
    }

    private fun showSettings(cfg: Map<String, String>) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(8), px(16), px(8))
        }
        for (sp in specsFor(cfg["camModel"] ?: "OV2640")) {
            val cur = cfg[sp.key]?.toIntOrNull() ?: 0
            when (sp.kind) {
                0 -> {
                    val v = cur.coerceIn(sp.min, sp.max)
                    val label = TextView(this).apply { text = "${sp.label}：$v"; setPadding(0, px(10), 0, 0) }
                    val bar = SeekBar(this)
                    bar.min = sp.min
                    bar.max = sp.max
                    bar.progress = v
                    bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                            label.text = "${sp.label}：$p"
                        }
                        override fun onStartTrackingTouch(s: SeekBar?) {}
                        override fun onStopTrackingTouch(s: SeekBar?) {
                            applySetting(sp.key, bar.progress.toString())
                        }
                    })
                    root.addView(label)
                    root.addView(bar)
                }
                1 -> {
                    val sw = Switch(this)
                    sw.text = sp.label
                    sw.isChecked = cur != 0
                    sw.setPadding(0, px(12), 0, px(4))
                    sw.setOnCheckedChangeListener { _, on -> applySetting(sp.key, if (on) "1" else "0") }
                    root.addView(sw)
                }
                else -> {
                    root.addView(TextView(this).apply { text = sp.label; setPadding(0, px(10), 0, 0) })
                    val spinner = Spinner(this)
                    val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, sp.options)
                    ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    spinner.adapter = ad
                    spinner.setSelection(cur.coerceIn(0, sp.options.size - 1))
                    var initial = true
                    spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                        override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                            if (initial) initial = false else applySetting(sp.key, pos.toString())
                        }
                        override fun onNothingSelected(p: AdapterView<*>?) {}
                    }
                    root.addView(spinner)
                }
            }
        }
        AlertDialog.Builder(this).setTitle("設定")
            .setView(ScrollView(this).apply { addView(root) })
            .setPositiveButton("儲存到裝置") { _, _ ->
                bg {
                    CamApi.control(curNet, curIp, "save", "1")
                    runOnUiThread { toast("已儲存到裝置") }
                }
            }
            .setNegativeButton("關閉", null)
            .setOnDismissListener { poller?.reloadConfig() }
            .show()
    }

    // ---------------------------------------------------------------- file browser

    private fun openFiles(path: String) {
        if (recording) { toast("錄影中無法瀏覽檔案，請先停止錄影"); return }
        bg {
            val list = CamApi.list(curNet, curIp, path)
            runOnUiThread { showFileDialog(path, list) }
        }
    }

    private fun showFileDialog(path: String, list: List<FileEntry>) {
        val up = path != "/"
        val labels = ArrayList<String>()
        if (up) labels.add("⬆ 返回日期列表")
        list.forEach { labels.add((if (it.isDir) "📂 " else "🎞 ") + it.label) }
        val b = AlertDialog.Builder(this).setTitle((if (up) path else "SD 卡錄影") + "（長按項目可刪除）")
        if (labels.isEmpty()) b.setMessage("沒有錄影檔案")
        else b.setItems(labels.toTypedArray()) { _, i ->
            val idx = if (up) i - 1 else i
            if (idx < 0) openFiles("/")
            else {
                val e = list[idx]
                if (e.isDir) openFiles(e.path) else showFileActions(e, path)
            }
        }
        b.setNegativeButton("關閉", null)
        val dlg = b.show()
        if (labels.isNotEmpty()) {
            dlg.listView.setOnItemLongClickListener { _, _, pos, _ ->
                val idx = if (up) pos - 1 else pos
                if (idx >= 0) { dlg.dismiss(); confirmDelete(list[idx], path); true } else false
            }
        }
    }

    private fun showFileActions(e: FileEntry, parent: String) {
        AlertDialog.Builder(this).setTitle(e.label)
            .setItems(arrayOf("▶ 播放", "⬇ 下載到手機（Download/ESP32CAM）", "🗑 刪除")) { _, i ->
                when (i) {
                    0 -> playFile(e)
                    1 -> downloadFile(e)
                    else -> confirmDelete(e, parent)
                }
            }
            .setNegativeButton("取消", null).show()
    }

    /** /control?delete=<path> (a folder path deletes the whole day folder) */
    private fun confirmDelete(e: FileEntry, refresh: String) {
        AlertDialog.Builder(this).setTitle("刪除")
            .setMessage("確定刪除 ${e.label}？此操作無法復原" + if (e.isDir) "\n（整個資料夾與其中所有錄影）" else "")
            .setPositiveButton("刪除") { _, _ ->
                bg {
                    CamApi.control(curNet, curIp, "delete", e.path)
                    runOnUiThread { toast("已刪除"); openFiles(refresh) }
                }
            }
            .setNegativeButton("取消", null).show()
    }

    /**
     * /control?sfile=<path> then /sustain?playback=0 (live stream must be closed first: both use sustain task 0).
     * After a delete the firmware refuses the first playback request (stopPlayback stays set) and resets it
     * while refusing, so a playback that ends without any frame is retried once automatically.
     */
    private fun playFile(e: FileEntry, attempt: Int = 0) {
        stopClient()
        mode = Mode.PLAYBACK
        busyText = "播放 ${e.label}"
        updateButtons()
        bg(onFail = { backToLive() }) {
            CamApi.control(curNet, curIp, "stopPlaying", "1")
            CamApi.control(curNet, curIp, "sfile", e.path)
            runOnUiThread {
                if (mode != Mode.PLAYBACK || !connected) return@runOnUiThread
                val got = AtomicBoolean(false)
                client = MjpegClient(curNet, curIp,
                    onFrame = { bmp -> got.set(true); onFrame(bmp) },
                    onError = { msg -> runOnUiThread { toast("播放錯誤: $msg") } },
                    path = "/sustain?playback=0",
                    loop = false,
                    onEnd = {
                        runOnUiThread {
                            if (mode == Mode.PLAYBACK) {
                                if (!got.get() && attempt == 0) playFile(e, 1)
                                else { if (!got.get()) toast("播放失敗"); backToLive() }
                            }
                        }
                    }
                ).also { it.start() }
            }
        }
    }

    private fun downloadFile(e: FileEntry) {
        stopClient()
        mode = Mode.BUSY
        busyText = "下載 ${e.label}"
        updateButtons()
        bg(onFail = { backToLive() }) {
            val name = CamApi.download(this, curNet, curIp, e.path) { done, total ->
                runOnUiThread {
                    busyText = "下載中 ${done / 1024}KB" + if (total > 0) " / ${total / 1024}KB" else ""
                    refreshInfo()
                }
            }
            runOnUiThread { toast("已儲存: Download/ESP32CAM/$name"); backToLive() }
        }
    }

    // ---------------------------------------------------------------- info bar

    private fun refreshInfo() {
        if (!connected) return
        errorText?.let { info.text = "錯誤: $it (重試中...)"; return }
        val s = status
        val parts = ArrayList<String>()
        if (recording) parts.add("● REC")
        busyText?.let { parts.add(it) }
        if (frameSize.isNotEmpty()) parts.add("解析度 $frameSize")
        parts.add("實際 %.0f fps".format(fps))
        s["fps"]?.let { parts.add("設定 $it fps") }
        s["quality"]?.let { parts.add("品質 $it") }
        s["camModel"]?.let { parts.add(it) }
        s["wifi_rssi"]?.let { parts.add("RSSI $it") }
        s["llevel"]?.let { parts.add("亮度 $it%") }
        s["atemp"]?.let { parts.add("溫度 ${it}°C") }
        s["free_heap"]?.let { parts.add("Heap $it") }
        s["free_psram"]?.let { parts.add("PSRAM $it") }
        s["up_time"]?.let { parts.add("運行 $it") }
        info.text = parts.joinToString("  |  ")
    }

    override fun onStop() {
        super.onStop()
        if (connected) disconnect()   // free the camera's stream task when app goes to background
    }

    override fun onDestroy() {
        super.onDestroy()
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        netCallback?.let { runCatching { cm.unregisterNetworkCallback(it) } }
        cm.bindProcessToNetwork(null)
    }
}
