package com.example.esp32camviewer

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Network
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

private fun openConn(net: Network?, url: String, method: String = "GET", readTimeout: Int = 8000): HttpURLConnection {
    val u = URL(url)
    val c = (if (net != null) net.openConnection(u) else u.openConnection()) as HttpURLConnection
    c.requestMethod = method
    c.connectTimeout = 5000
    c.readTimeout = readTimeout
    return c
}

private fun httpGetText(net: Network?, url: String): String {
    val c = openConn(net, url)
    try {
        return c.inputStream.bufferedReader().use { it.readText() }
    } finally {
        c.disconnect()
    }
}

/**
 * The web page always sends HEAD before GET on /sustain: the firmware uses it to check/free sustain task 0.
 * Retry a few times because the previous stream/playback may need a moment to release the task.
 */
private fun preflight(net: Network?, url: String, isRunning: () -> Boolean = { true }) {
    for (i in 0 until 10) {
        if (!isRunning()) return
        try {
            val h = openConn(net, url, "HEAD")
            val code = h.responseCode
            h.disconnect()
            if (code == 200) return
        } catch (e: Exception) {
        }
        Thread.sleep(300)
    }
}

data class FileEntry(val path: String, val label: String, val isDir: Boolean)

/** Simple /control and file APIs of ESP32-CAM_MJPEG2SD */
object CamApi {
    /** GET /control?key=value  (e.g. forceRecord=1, lampLevel=15, sfile=/path) */
    fun control(net: Network?, host: String, key: String, value: String): String {
        val c = openConn(net, "http://$host/control?$key=${Uri.encode(value, "/")}")
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** full status incl. current config values (GET /status) */
    fun status(net: Network?, host: String): Map<String, String> {
        val j = JSONObject(httpGetText(net, "http://$host/status"))
        val out = HashMap<String, String>()
        val keys = j.keys()
        while (keys.hasNext()) { val k = keys.next(); out[k] = j.optString(k) }
        return out
    }

    /** list day folders ("/") or AVI files of a day folder ("/20260101") */
    fun list(net: Network?, host: String, path: String): List<FileEntry> {
        val text = control(net, host, "sfile", path).trim()
        if (!text.startsWith("{")) return emptyList()
        val j = JSONObject(text)
        val out = ArrayList<FileEntry>()
        val keys = j.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            if (k == "/" || k.startsWith("/~")) continue   // "up" and shortcut entries
            out.add(FileEntry(k, j.optString(k), !k.endsWith(".avi", ignoreCase = true)))
        }
        return out
    }

    /** download file to Downloads/ESP32CAM using MediaStore (API 29+, no permission needed) */
    fun download(ctx: Context, net: Network?, host: String, path: String, onProgress: (Long, Long) -> Unit): String {
        control(net, host, "stopPlaying", "1")
        control(net, host, "sfile", path)        // selects the file on the device
        val url = "http://$host/sustain?download=0"
        preflight(net, url)
        val c = openConn(net, url, "GET", 15000)
        try {
            if (c.responseCode != 200) throw RuntimeException("HTTP ${c.responseCode}")
            val name = c.getHeaderField("Content-Disposition")
                ?.substringAfter("filename=", "")?.trim()?.trim('"')?.takeIf { it.isNotEmpty() }
                ?: path.substringAfterLast('/')
            val total = c.contentLengthLong
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE,
                    if (name.endsWith(".avi", true)) "video/x-msvideo" else "application/octet-stream")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ESP32CAM")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = ctx.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw RuntimeException("無法建立檔案")
            try {
                resolver.openOutputStream(uri)!!.use { out ->
                    c.inputStream.use { ins ->
                        val buf = ByteArray(64 * 1024)
                        var done = 0L
                        var lastReport = 0L
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            if (done - lastReport >= 256 * 1024) { lastReport = done; onProgress(done, total) }
                        }
                        onProgress(done, total)
                    }
                }
                val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                resolver.update(uri, done, null, null)
            } catch (e: Exception) {
                resolver.delete(uri, null, null)
                throw e
            }
            return name
        } finally {
            c.disconnect()
        }
    }
}

/**
 * MJPEG2SD stream. path = /sustain?stream=0 (live) or /sustain?playback=0 (SD playback).
 * Response is multipart/x-mixed-replace; each part has "Content-Length: n" followed by the JPEG.
 * loop=true : reconnect on error (live). loop=false : stop at end of stream and call onEnd (playback).
 */
class MjpegClient(
    private val net: Network?,
    private val host: String,
    private val onFrame: (Bitmap) -> Unit,
    private val onError: (String) -> Unit,
    private val path: String = "/sustain?stream=0",
    private val loop: Boolean = true,
    private val onEnd: () -> Unit = {}
) {
    @Volatile private var running = false
    @Volatile private var conn: HttpURLConnection? = null

    fun start() {
        running = true
        Thread({
            try {
                while (running) {
                    try {
                        streamOnce()
                        if (!loop) break
                    } catch (e: Exception) {
                        if (running) {
                            onError(e.message ?: e.javaClass.simpleName)
                            if (!loop) break
                        }
                    }
                    var waited = 0
                    while (running && waited < 2000) { Thread.sleep(100); waited += 100 }
                }
            } catch (e: InterruptedException) {
            }
            if (!loop && running) { running = false; onEnd() }
        }, "mjpeg").start()
    }

    fun stop() {
        running = false
        conn?.disconnect()   // unblocks the blocking read
    }

    private fun streamOnce() {
        val url = "http://$host$path"
        preflight(net, url) { running }
        if (!running) return

        val c = openConn(net, url, "GET", 10000)
        conn = c
        if (c.responseCode != 200) {
            c.disconnect()
            throw RuntimeException("HTTP ${c.responseCode}")
        }
        BufferedInputStream(c.inputStream, 64 * 1024).use { ins ->
            while (running) {
                val len = readPartLength(ins)
                if (len <= 0) {
                    if (loop) throw RuntimeException("串流結束")
                    return
                }
                val buf = ByteArray(len)
                var off = 0
                while (off < len) {
                    val n = ins.read(buf, off, len - off)
                    if (n < 0) throw RuntimeException("串流中斷")
                    off += n
                }
                BitmapFactory.decodeByteArray(buf, 0, len)?.let(onFrame)
            }
        }
        c.disconnect()
    }

    private fun readLine(ins: InputStream): String? {
        val sb = StringBuilder()
        while (sb.length < 512) {
            val b = ins.read()
            if (b < 0) return null
            if (b == '\n'.code) return sb.toString().trimEnd('\r')
            sb.append(b.toChar())
        }
        return sb.toString()
    }

    /** skips boundary line, reads part headers, returns JPEG size (or -1 on EOF) */
    private fun readPartLength(ins: InputStream): Int {
        var len = -1
        while (true) {
            val line = readLine(ins) ?: return -1
            if (line.isEmpty()) {
                if (len >= 0) return len else continue
            }
            if (line.startsWith("Content-Length", ignoreCase = true)) {
                len = line.substringAfter(':').trim().toIntOrNull() ?: -1
            }
        }
    }
}

/**
 * Polls device status. /status (no query) returns config values (fps, quality ...) and is read at start
 * and after reloadConfig(); /status?q returns the light-weight runtime status (llevel, atemp, wifi_rssi ...).
 */
class StatusPoller(
    private val net: Network?,
    private val host: String,
    private val onStatus: (Map<String, String>) -> Unit
) {
    @Volatile private var running = false
    @Volatile private var full = true
    private val data = HashMap<String, String>()

    /** re-read the full config at the next poll (after settings were changed) */
    fun reloadConfig() { full = true }

    fun start() {
        running = true
        Thread({
            while (running) {
                try {
                    val path = if (full) "/status" else "/status?q"
                    val j = JSONObject(httpGetText(net, "http://$host$path"))
                    val keys = j.keys()
                    while (keys.hasNext()) { val k = keys.next(); data[k] = j.optString(k) }
                    full = false
                    onStatus(HashMap(data))
                } catch (e: Exception) {
                }
                var w = 0
                while (running && w < 3000) { Thread.sleep(100); w += 100 }
            }
        }, "status").start()
    }

    fun stop() { running = false }
}
